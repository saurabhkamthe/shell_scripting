################################
#Title : Menu Driven
#question 2
#Author : Saurabh Kamthe
################################


#!/bin/bash

MAX=7

for (( i=1; i<=MAX; i++ ))
do
	for (( s=MAX; s>=i; s-- ))
	do
	echo -n " "
done
for (( j=1; j<=i;  j++ ))
do
	echo -n " #"
	done
	echo ""
done

for (( i=MAX; i>=1; i-- ))
do
	for (( s=i; s<=MAX; s++ ))
	do
		echo -n " "
	done
	for (( j=1; j<=i;  j++ ))
	do
		echo -n " #"
	done
	echo ""
done

#Menu For The User

ans=1

while [ $ans == 1 ]
do
	echo "***********************************************"
	echo "Menu"
	echo "1.List Files"
	echo "2.Creat File"
	echo "3.Copy The Content Of One File To Another File"
	echo "4.Move File"
	echo "5.Compress Files Directory"
	echo "6.Extract Files"
	echo "7.Exit"
	echo "***********************************************"

	echo "Ente your choice : "
	read ch

	case $ch in
		1)echo "Files are : "
		ls ;;
		2)echo "Enter the name of the file to be created : "
		read file
		touch $file
		echo "File created" ;;
		3)echo "Enter the name of the 1st and and 2nd files : "
		read f1
		read f2
		cat $f1 >> $f2
		echo "Contents of $f1 copied to $f2" ;;
		4)echo "Enter the file name : "
		read f
		echo "Enter the dir name : "
		read dir
		mv $f $dir
		echo "$f moved to $dir" ;;
		5)echo "Enter the directory to be compressed : "
		read dir_compress
		zip -r $dir_compress.zip $dir_compress
		echo "Files are zipped" ;;
		6)echo "Enter the zip file name : "
		read zip
		unzip $zip 
		echo "Directory is unzipped" ;;
		*)echo "Exiting!!"
		ans=0 ;;
	esac
done
